//
//  GuiaAnafilaxiaView.swift
//  MediAlert
//

import SwiftUI

struct GuiaAnafilaxiaView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("Guía: Síntomas en la Anafilaxia")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Spacer()
                    
                    
                    Button(action: {}) {
                        Image(systemName: "message")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 24, height: 24)
                            .foregroundColor(.blue)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 15)
                .padding(.bottom, 10)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text("1. Piel")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                Spacer()
                                
                             
                                Rectangle()
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(width: 60, height: 60)
                                    .cornerRadius(8)
                                    .overlay(
                                        Image(systemName: "photo")
                                            .foregroundColor(.gray)
                                    )
                            }
                            
                            Text("• Ronchas rojas que pican.")
                                .font(.body)
                            Text("• Hinchazón y/o picor en palmas de las manos.")
                                .font(.body)
                            Text("• Hinchazón y/o picor en plantas de los pies.")
                                .font(.body)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                        
                      
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text("2. Respiratorio")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                Spacer()
                                
                             
                                Rectangle()
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(width: 60, height: 60)
                                    .cornerRadius(8)
                                    .overlay(
                                        Image(systemName: "photo")
                                            .foregroundColor(.gray)
                                    )
                            }
                            
                            Text("• Tos")
                                .font(.body)
                            Text("• Sensación de algo atorado en la garganta")
                                .font(.body)
                            Text("• Silbidos en el pecho")
                                .font(.body)
                            Text("• Falta de aire")
                                .font(.body)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                        
                    
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text("3. Cardiovascular")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                Spacer()
                                
                                
                                Rectangle()
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(width: 60, height: 60)
                                    .cornerRadius(8)
                                    .overlay(
                                        Image(systemName: "photo")
                                            .foregroundColor(.gray)
                                    )
                            }
                            
                            Text("• Papilaciones")
                                .font(.body)
                            Text("• Mareo")
                                .font(.body)
                            Text("• Baja presión")
                                .font(.body)
                            Text("• Desmayo")
                                .font(.body)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                        
                       
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text("4. Digestivo")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                Spacer()
                                
                       
                                Rectangle()
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(width: 60, height: 60)
                                    .cornerRadius(8)
                                    .overlay(
                                        Image(systemName: "photo")
                                            .foregroundColor(.gray)
                                    )
                            }
                            
                            Text("• Nauseas")
                                .font(.body)
                            Text("• Vómito")
                                .font(.body)
                            Text("• Dearra")
                                .font(.body)
                            Text("• Saber Metálico en la boca")
                                .font(.body)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                        
                      
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Qué hacer si detectas valores anormales")
                                .font(.headline)
                                .fontWeight(.semibold)
                                .foregroundColor(.red)
                            
                            Text("•Mantener la calma.")
                                .font(.body)
                            Text("• Sistema de medios para confirmar.")
                                .font(.body)
                            Text("• Si tiene valores con dos etapas (diseño), tienes a emergencias desde la app o contacto.")
                                .font(.body)
                            Text("• Si la persona tiene hipertensión, no suspendas su tratamiento y acta al esfuerzo físico.")
                                .font(.body)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                    }
                    .padding(.horizontal, 15)
                    .padding(.vertical, 10)
                }
                
          
                HStack {
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "bell")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Alertas")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "house")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Inicio")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
      
                    Button(action: {}) {
                        VStack {
                            ZStack {
                                Circle()
                                    .fill(Color.red)
                                    .frame(width: 50, height: 50)
                                Text("SOS")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .fontWeight(.bold)
                            }
                        }
                    }
                    .offset(y: -15)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "book")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Info")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "person")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Perfil")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
                .padding(.top, 10)
                .padding(.bottom, 5)
                .background(Color.white)
                .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: -1)
            }
            .background(Color(.systemGroupedBackground))
            .navigationBarHidden(true)
        }
    }
}

#Preview {
    GuiaAnafilaxiaView()
}
