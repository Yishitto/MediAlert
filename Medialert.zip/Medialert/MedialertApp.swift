//
//  MedialertApp.swift
//  Medialert
//
//  Created by Yishai Dávila on 21/09/25.
//

import SwiftUI

@main
struct MedialertApp: App {
    var body: some Scene {
        WindowGroup {
            GuiaAnafilaxiaQueHacerView()
        }
    }
}
