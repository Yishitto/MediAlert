
//

//  MediAlert

//

import SwiftUI

struct RecetasView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                
                HStack {
                    Text("Botiquín de Camila")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Spacer()
                    
                    
                    Button(action: {}) {
                        Image(systemName: "message")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 24, height: 24)
                            .foregroundColor(.blue)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 15)
                .padding(.bottom, 10)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                       
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Agregar Receta Médica")
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            Button(action: {}) {
                                Text("Subir Receta")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 12)
                                    .background(Color.blue)
                                    .cornerRadius(8)
                            }
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Fecha:")
                                    .font(.subheadline)
                                TextField("", text: .constant(""))
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .frame(height: 35)
                            }
                            .padding(.top, 5)
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Imagen:")
                                    .font(.subheadline)
                                
                                
                                Rectangle()
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(height: 150)
                                    .cornerRadius(8)
                                    .overlay(
                                        Image(systemName: "photo")
                                            .font(.largeTitle)
                                            .foregroundColor(.gray)
                                    )
                            }
                            .padding(.top, 5)
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Fecha 30/08/2025")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            .padding(.top, 5)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                    }
                    .padding(.horizontal, 15)
                    .padding(.vertical, 10)
                }
                
       
                HStack {
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "bell")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Alertas")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "house")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Inicio")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
             
                    Button(action: {}) {
                        VStack {
                            
                            ZStack {
                                Circle()
                                    .fill(Color.red)
                                    .frame(width: 50, height: 50)
                                Text("SOS")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .fontWeight(.bold)
                            }
                        }
                    }
                    .offset(y: -15)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "book")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Info")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "person") 
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Perfil")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
                .padding(.top, 10)
                .padding(.bottom, 5)
                .background(Color.white)
                .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: -1)
            }
            .background(Color(.systemGroupedBackground))
            .navigationBarHidden(true)
        }
    }
}

#Preview {
    RecetasView()
}
