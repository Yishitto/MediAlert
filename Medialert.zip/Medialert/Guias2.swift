//
//  Guias2.swift
//  Medialert
//
//  Created by Yishai Dávila on 21/09/25.
//

//
//  GuiaAnafilaxiaQueHacerView.swift
//

import SwiftUI

struct GuiaAnafilaxiaQueHacerView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("Guía: ¿Qué hacer cuando se presenta una anafilexia?")
                        .font(.title2)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.leading)
                    
                    Spacer()
                    
                    
                    Button(action: {}) {
                        Image(systemName: "message")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 24, height: 24)
                            .foregroundColor(.blue)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 15)
                .padding(.bottom, 10)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        
                        VStack(alignment: .leading, spacing: 8) {
                            HStack(alignment: .top) {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("1. Reconocer la Anafilexia")
                                        .font(.headline)
                                        .fontWeight(.semibold)
                                    
                                    Text("• Es una reacción alérgica grave de presentación rápida y puede ser mortal.")
                                        .font(.body)
                                    Text("• Se estima que ocurren entre 50 y 112 episodios de anafilaxia por cada 100.000 personas por año.")
                                        .font(.body)
                                    Text("• Entre estos casos, la mortalidad se ha situado entre el 0,05 y el 2 %.")
                                        .font(.body)
                                    Text("(Consultar la siguiente Guía para reconocer los Síntomas de la Anafilexia).")
                                        .font(.body)
                                        .italic()
                                }
                                
                                Spacer()
                                
                              
                                Rectangle()
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(width: 80, height: 80)
                                    .cornerRadius(8)
                                    .overlay(
                                        Image(systemName: "photo")
                                            .foregroundColor(.gray)
                                    )
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                        
                       
                        VStack(alignment: .leading, spacing: 8) {
                            HStack(alignment: .top) {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("2. Retirado del alérgeno")
                                        .font(.headline)
                                        .fontWeight(.semibold)
                                    
                                    Text("• Suspender la administración de fármacos supuestamente responsables de la anafilaxia.")
                                        .font(.body)
                                    Text("• Intentar retirar el aguijón tras picadura de abeja. En este caso prima la rapidez de la extracción sobre la forma de hacerlo")
                                        .font(.body)
                                    Text("• No intentar provocarse el vómito en una anafilaxia producida por alimentos, pero sí retirar restos alimentarios de la boca")
                                        .font(.body)
                                    Text("• Retirar productos de látex (guantes, sondas...) si se sospecha alergia al mismo.")
                                        .font(.body)
                                }
                                
                                Spacer()
                                
                               
                                Rectangle()
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(width: 80, height: 80)
                                    .cornerRadius(8)
                                    .overlay(
                                        Image(systemName: "photo")
                                            .foregroundColor(.gray)
                                    )
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                        
                       
                        VStack(alignment: .leading, spacing: 8) {
                            HStack(alignment: .top) {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("3. Aplicar la Adrenalina RÁPIDAMENTE")
                                        .font(.headline)
                                        .fontWeight(.semibold)
                                    
                                    Text("• Preparar la jeringa: Retira la tapa de la aguja y asegúrate de que la dosis de adrenalina esté correctamente cargada en la jeringa.")
                                        .font(.body)
                                    Text("• Ubica el área de inyección: Identifica el costado del muslo, a medio camino entre la cadera y la rodilla")
                                        .font(.body)
                                    Text("• Inyecta la adrenalina: Sostén la jeringa firmemente y, con un ángulo de 90 grados, inserta la aguja en el músculo del muslo.")
                                        .font(.body)
                                    Text("• Retira la aguja y masajea: Retira la aguja rápidamente y masajea suavemente la zona para ayudar a dispersar la adrenalina")
                                        .font(.body)
                                }
                                
                                Spacer()
                                
                                
                                Rectangle()
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(width: 80, height: 80)
                                    .cornerRadius(8)
                                    .overlay(
                                        Image(systemName: "photo")
                                            .foregroundColor(.gray)
                                    )
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                    }
                    .padding(.horizontal, 15)
                    .padding(.vertical, 10)
                }
                
                
                HStack {
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "bell")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Alertas")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "house")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Inicio")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                   
                    Button(action: {}) {
                        VStack {
                            ZStack {
                                Circle()
                                    .fill(Color.red)
                                    .frame(width: 50, height: 50)
                                Text("SOS")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .fontWeight(.bold)
                            }
                        }
                    }
                    .offset(y: -15)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "book")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Info")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "person")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Perfil")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
                .padding(.top, 10)
                .padding(.bottom, 5)
                .background(Color.white)
                .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: -1)
            }
            .background(Color(.systemGroupedBackground))
            .navigationBarHidden(true)
        }
    }
}

#Preview {
    GuiaAnafilaxiaQueHacerView()
}
