//
//  Botiquin1.swift
//  Medialert
//
//  Created by Yishai Dávila on 21/09/25.
//
import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("Botiquín de Camila")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Spacer()
                    
                   
                    Button(action: {}) {
                        Image(systemName: "message")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 24, height: 24)
                            .foregroundColor(.blue)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 15)
                .padding(.bottom, 10)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                       
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Agregar Medicamento")
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Nombre:")
                                    .font(.subheadline)
                                TextField("", text: .constant(""))
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .frame(height: 35)
                            }
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Dosis:")
                                    .font(.subheadline)
                                TextField("", text: .constant(""))
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .frame(height: 35)
                            }
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Cada cuánto:")
                                    .font(.subheadline)
                                TextField("", text: .constant(""))
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .frame(height: 35)
                            }
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Durante:")
                                    .font(.subheadline)
                                TextField("", text: .constant(""))
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .frame(height: 35)
                            }
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Fecha de Caducidad:")
                                    .font(.subheadline)
                                TextField("", text: .constant(""))
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .frame(height: 35)
                            }
                            
                            Button(action: {}) {
                                Text("Agregar")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 12)
                                    .background(Color.blue)
                                    .cornerRadius(8)
                            }
                            .padding(.top, 5)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                        
                   
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Medicamentos")
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Adrenalina")
                                    .font(.headline)
                                    .fontWeight(.bold)
                                
                                HStack {
                                    Text("Dosis")
                                        .font(.subheadline)
                                    Spacer()
                                    Text("5 mg")
                                        .font(.subheadline)
                                }
                                
                                HStack {
                                    Text("Cada cuánto:")
                                        .font(.subheadline)
                                    Spacer()
                                    Text("Cada 8 hrs")
                                        .font(.subheadline)
                                }
                                
                                HStack {
                                    Text("Durante")
                                        .font(.subheadline)
                                    Spacer()
                                    Text("5 días")
                                        .font(.subheadline)
                                }
                                
                                HStack {
                                    Text("Fecha de Caducidad:")
                                        .font(.subheadline)
                                    Spacer()
                                    Text("30/08/2023")
                                        .font(.subheadline)
                                        .foregroundColor(.red)
                                }
                            }
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                            
                            
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Corticoides")
                                    .font(.headline)
                                    .fontWeight(.bold)
                                
                                
                            }
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                    }
                    .padding(.horizontal, 15)
                    .padding(.vertical, 10)
                }
                
               
                HStack {
                   
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "bell")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Alertas")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "house")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Inicio")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
          
                    Button(action: {}) {
                        VStack {
                           
                            ZStack {
                                Circle()
                                    .fill(Color.red)
                                    .frame(width: 50, height: 50)
                                Text("SOS")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .fontWeight(.bold)
                            }
                        }
                    }
                    .offset(y: -15)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "book")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Info")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    Button(action: {}) {
                        VStack {
                            Image(systemName: "person") 
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                            Text("Perfil")
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
                .padding(.top, 10)
                .padding(.bottom, 5)
                .background(Color.white)
                .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: -1)
            }
            .background(Color(.systemGroupedBackground))
            .navigationBarHidden(true)
        }
    }
}

#Preview {
    ContentView()
}
